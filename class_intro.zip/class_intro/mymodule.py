"""
Here you write a module help. Try help(mymodule) after importing.
"""

def func1():
    """ Help for func1. """
    print("You called func1!")
